/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ValidacionesCredenciales;

/**
 *
 * @author josue
 */
public class Libreria {

    private static Iterable<Usuarios> usuarios;
    
    public static boolean esCorreoValido(String correo) {
       
        String[] dominiosValidos = {"@gmail", "@outlook", "@hotmail", "@yahoo", "@itoaxaca"};
        boolean dominioValido = false;
        
        for (String dominio : dominiosValidos) {
            if (correo.contains(dominio)) {
                dominioValido = true;
                break;
            }
        }

        
        String[] extensionesValidas = {".com", ".mx", ".edu"};
        boolean extensionValida = false;
        
        for (String extension : extensionesValidas) {
            if (correo.endsWith(extension)) {
                extensionValida = true;
                break;
            }
        }

        return dominioValido && extensionValida;
    }
    
    
    public static boolean esContrasenaValida(String correo, String contrasena) {
        
    if (contrasena.length() != 8) {
            return false;
        }

        // Obtener la parte del correo antes del @
        int indexArroba = correo.indexOf("@");
        if (indexArroba == -1) {
            return false; // Correo inválido (no tiene @)
        }

        String parteUsuario = correo.substring(0, indexArroba);

       
        if (!contrasena.startsWith(parteUsuario)) {
            return false;
        }

       
        boolean tieneNumero = false;
        for (char c : contrasena.toCharArray()) {
            if (Character.isDigit(c)) {
                tieneNumero = true;
                break;
            }
        }

        return tieneNumero;
    }
    public static boolean esUsuarioValido(String correo, String contraseña){
    for (Usuarios usuario : usuarios) {
            if (usuario.getCorreo().equals(correo) && usuario.getContraseña().equals(contraseña)) {
               
                return true;
            }else{
            System.out.println("El usuario no existe");
            }}
        return false;
}}
