/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ValidacionesCredenciales;

/**
 *
 * @author josue
 */
public class Usuarios {
    private String nombre;
     private String apellidos;
    private String contraseña;
     private String correo;
   

    public Usuarios(String nombre,String apellidos,String correo, String contraseña) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.correo=correo;
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre+apellidos;
    }
    
    public String getCorreo() {
        return correo;
    }

    public String getContraseña() {
        return contraseña;
    }
}
